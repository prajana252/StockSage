import os, sys, json
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from src.data.loader import load_bundled
from src.evaluation.benchmark import run_benchmark
r = run_benchmark(load_bundled()); r.pop("alerts")
os.makedirs("docs", exist_ok=True); json.dump(r, open("docs/benchmark_results.json", "w"), indent=2)
print(json.dumps(r, indent=2))
