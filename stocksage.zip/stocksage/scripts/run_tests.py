"""Fallback runner if pytest isn't installed: python scripts/run_tests.py"""
import os, sys, glob, importlib.util, traceback
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
fails = n = 0
for f in sorted(glob.glob("tests/test_*.py")):
    spec = importlib.util.spec_from_file_location(os.path.basename(f)[:-3], f); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    for name in dir(m):
        if name.startswith("test_"):
            n += 1
            try: getattr(m, name)(); print("PASS", name)
            except Exception: fails += 1; print("FAIL", name); traceback.print_exc()
print(f"{n-fails}/{n} passed"); sys.exit(1 if fails else 0)
