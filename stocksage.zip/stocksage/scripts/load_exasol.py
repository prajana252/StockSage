"""Load the bundled demo dataset into Exasol and run the SQL feature query. Usage: python scripts/load_exasol.py"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from dotenv import load_dotenv
from src.data.loader import load_bundled
from src.database.exasol_client import ExasolClient

if __name__ == "__main__":
    load_dotenv()
    c = ExasolClient().connect()
    print(c.health_check())
    d = load_bundled(); c.load_dataset(d)
    print("Loaded. Feature query preview:")
    print(c.sql_features(str(d["sales"]["sale_date"].max().date())).head(10))
    c.close()
