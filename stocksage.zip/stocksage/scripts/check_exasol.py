import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from dotenv import load_dotenv
from src.database.exasol_client import ExasolClient
load_dotenv(); print(ExasolClient().health_check())
