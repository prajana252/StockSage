import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from src.data.generate import write_csvs
if __name__ == "__main__":
    d = write_csvs("data"); print({k: len(v) for k, v in d.items()})
