# Architecture
```mermaid
flowchart LR
  A[CSV upload / bundled demo CSVs] --> B[Validation<br/>src/data/validation.py]
  B --> C{Mode}
  C -- live --> D[(Exasol tables<br/>sql/schema.sql)]
  D --> E[SQL features<br/>sql/features.sql]
  C -- demo --> F[pandas features]
  E --> G[Forecast WABL + stockout simulation<br/>src/inventory/engine.py]
  F --> G
  G --> H[Risk + reorder policy]
  H --> I[Streamlit dashboard]
  G --> J[Rolling-origin benchmark]
```
In demo mode the Exasol branch is skipped; the UI labels the mode. Python owns forecasting/simulation; Exasol owns storage and set-based aggregation.
