# 3-minute demo (numbers from the bundled dataset, as of 2026-06-30)
1. **(20s) Hook.** "A shop owner finds out an item is gone when a customer asks. StockSage tells you days earlier."
2. **(30s) Command centre.** Point at High/Critical count and the chart *days to stockout vs. lead time*. Say money figures are estimates.
3. **(40s) Example.** Open **SKU004 Green Tea Bottles**: 932 on hand, 14.8 days of coverage — a 7-day rule says "safe". But the supplier is ~3.6 days late on average (effective lead time 16 days) and 28-day demand is +42% → projected stockout in 14 days, *before* a new order can arrive. Evidence bullets are computed, not typed.
4. **(30s) Recommendation.** Order 780 units today (MOQ/pack-aware), delivery ≈ 2026-07-16; warning that it lands after the stockout → expedite.
5. **(30s) What-if.** Add 5 days supplier delay → lead time 21 d, recommended order rises to 1,152 units.
6. **(20s) Benchmark.** Precision 0.865 vs 0.254 for a 14-day coverage rule, recall 0.80 vs 0.85. Be upfront: synthetic data.
7. **(10s) Exasol.** Sales, stock, suppliers and POs live in Exasol; rolling demand, lateness and open-PO features are SQL; show *Method & Exasol* tab. (Only say this live if you completed the Exasol steps.)

**Pitch:** "Exasol lets us join years of sales with inventory and supplier data and compute rolling features set-based in SQL; StockSage adds a transparent forecast and replenishment layer so every alert is explainable."
