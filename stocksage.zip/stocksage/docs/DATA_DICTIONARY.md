# Data dictionary (synthetic, seed 42, 36 SKUs × 420 days ending 2026-06-30)
| File | Columns |
|---|---|
| sample_sales.csv | sale_date, sku, units_sold (fulfilled units; days with no sales = 0) |
| sample_inventory.csv | sku, product_name, category, on_hand (end of as-of day), unit_price, unit_cost, supplier_id, moq, pack_size |
| sample_suppliers.csv | supplier_id, supplier_name, lead_time_days (promised) |
| sample_purchase_orders.csv | po_id, sku, order_date, expected_date, received_date (blank = still open), quantity |
| sample_stock_history.csv | date, sku, on_hand, unmet_units (benchmark ground truth; demo only) |
| sample_product_profiles.csv | sku, demand_profile (stable / rising / seasonal / intermittent / scenario) |

**Assumptions:** daily demand ~ Poisson(base × weekday factor × trend/season); sales = min(demand, stock), the rest is `unmet_units`; a simple reorder-point policy places orders;
actual delivery = promised lead time + supplier lateness (SUP4 ≈ 3.5 days late on average); five *scenario* SKUs get a late demand ramp (+3%/day over 28 days) while ordering stops for the final 21 days.
Intermittent SKUs have mostly zero days. Missing dates in uploaded sales are treated as zero sales.
